/* NOVAEON Online Multiplayer Alpha client.
 * Uses Supabase Auth/DB for persistent identity/social actions and native WebSocket for realtime rooms.
 * This layer is intentionally separate from the original single-player simulation.
 */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const root = $('mp-root');
  if (!root) return;

  const state = {
    mode: 'signin', session: null, user: null, profile: null, supa: null,
    socket: null, socketAuthed: false, reconnecting: false, suppressReconnect: false,
    room: null, friends: [], pendingRequests: [], notifications: [], serverReady: false, lastRenderedRoomKey: null,
    keys: new Set(), touchDirections: new Set(), lastInputAt: 0, roomCodeToJoin: null,
    currentTab: 'friends', wasOpen: false
  };
  const MAPS = {
    crystal_reach: 'CRYSTAL REACH',
    titan_graveyard: 'TITAN GRAVEYARD',
    derelict_station: 'DERELICT STATION',
    deep_void: 'DEEP VOID'
  };
  const MODES = {
    crystal_salvage: 'CRYSTAL SALVAGE',
    convoy_defense: 'CONVOY DEFENSE',
    reactor_breach: 'REACTOR BREACH'
  };
  const modeDescriptions = {
    crystal_salvage: 'Collect crystals, return to Extraction and use ACTION to deposit. Team goal: 12.',
    convoy_defense: 'Keep the convoy alive for 90 seconds. Use ACTION to pulse nearby enemy drones.',
    reactor_breach: 'Activate 3 reactor nodes in order. Stand close to a node and press ACTION.'
  };

  const setMessage = (id, message = '', kind = '') => {
    const el = $(id); if (!el) return;
    el.textContent = message;
    el.className = `mp-msg${kind ? ` ${kind}` : ''}`;
  };
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const shortId = (id) => String(id || '').slice(0, 8).toUpperCase();
  const showToast = (message, kind = '') => {
    const el = $('mp-room-msg');
    if (el) { el.textContent = message; el.className = `mp-msg${kind ? ` ${kind}` : ''}`; }
  };
  const setStatus = (message, good = false) => {
    $('mp-connection-status').textContent = message;
    $('mp-connection-status').style.color = good ? '#6dffb8' : 'var(--mut)';
  };
  const showRoot = () => { root.classList.add('open'); state.wasOpen = true; };
  const hideRoot = () => { root.classList.remove('open'); state.wasOpen = false; state.keys.clear(); state.touchDirections.clear(); };
  const canUseOnline = () => Boolean(state.supa && state.session && state.user && state.profile);
  const currentToken = () => state.session?.access_token || '';

  function switchAuthMode(mode) {
    state.mode = mode;
    const signUp = mode === 'signup';
    $('mp-auth-title').textContent = signUp ? 'CREATE PILOT ID // REGISTER' : 'PILOT IDENTITY // SIGN IN';
    $('mp-usn-wrap').hidden = !signUp;
    $('mp-nick-wrap').hidden = !signUp;
    $('mp-auth-submit').textContent = signUp ? 'CREATE ACCOUNT' : 'SIGN IN';
    $('mp-toggle-signup').textContent = signUp ? 'BACK TO SIGN IN' : 'CREATE PILOT ID';
    $('mp-password').autocomplete = signUp ? 'new-password' : 'current-password';
    setMessage('mp-auth-msg', '');
  }

  function setAuthVisible(signedIn) {
    $('mp-auth-view').hidden = signedIn;
    $('mp-app-view').hidden = !signedIn;
    $('mp-config-notice').hidden = Boolean(state.supa && state.serverReady);
    if (signedIn && state.profile) {
      const p = state.profile;
      $('mp-me-nick').textContent = p.nickname || p.username;
      $('mp-me-handle').textContent = `@${p.username}`;
      $('mp-profile-nick').textContent = p.nickname || p.username;
      $('mp-profile-usn').textContent = `@${p.username}`;
      $('mp-profile-id').textContent = `Account ID: ${p.id}`;
      $('mp-edit-nickname').value = p.nickname || '';
    }
  }

  async function loadMyProfile() {
    if (!state.supa || !state.user) return false;
    const { data, error } = await state.supa.from('profiles').select('id,username,nickname,created_at').eq('id', state.user.id).maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('Profil NOVAEON belum ditemukan. Jalankan supabase/schema.sql di SQL Editor, lalu coba lagi.');
    state.profile = data;
    setAuthVisible(true);
    return true;
  }

  function wsEndpoint() {
    const configured = window.NOVAEON_CONFIG?.wsUrl;
    if (configured) return configured.replace(/\/$/, '') + '/multiplayer';
    return `${location.protocol === 'https:' ? 'wss:' : 'ws:'}//${location.host}/multiplayer`;
  }

  function sendSocket(payload) {
    if (!state.socket || state.socket.readyState !== WebSocket.OPEN || !state.socketAuthed) {
      showToast('Koneksi multiplayer belum siap. Periksa status koneksi.');
      return false;
    }
    state.socket.send(JSON.stringify(payload));
    return true;
  }

  function connectSocket() {
    if (!currentToken() || !state.user) return;
    if (!state.serverReady) { setStatus('NODE SERVER / SUPABASE ADMIN CONFIGURATION REQUIRED'); return; }
    if (state.socket && (state.socket.readyState === WebSocket.OPEN || state.socket.readyState === WebSocket.CONNECTING)) return;
    state.suppressReconnect = false;
    setStatus('CONNECTING TO REALTIME SERVER…');
    let ws;
    try { ws = new WebSocket(wsEndpoint()); }
    catch (error) { setStatus('REALTIME CONNECTION FAILED'); showToast(error.message); return; }
    state.socket = ws;
    state.socketAuthed = false;
    ws.addEventListener('open', () => {
      ws.send(JSON.stringify({ type: 'auth', token: currentToken() }));
    });
    ws.addEventListener('message', (event) => {
      let message;
      try { message = JSON.parse(event.data); } catch { return; }
      handleServerMessage(message);
    });
    ws.addEventListener('error', () => setStatus('SERVER UNREACHABLE — CHECK NODE.JS TERMINAL'));
    ws.addEventListener('close', () => {
      state.socketAuthed = false;
      if (state.socket === ws) state.socket = null;
      setStatus('DISCONNECTED FROM REALTIME SERVER');
      if (state.room) {
        state.room = null;
        renderRoom();
      }
      if (state.session && !state.suppressReconnect && !state.reconnecting) {
        state.reconnecting = true;
        window.setTimeout(() => { state.reconnecting = false; if (state.session && !state.socket) connectSocket(); }, 2500);
      }
    });
  }

  function handleServerMessage(message) {
    switch (message.type) {
      case 'auth_ok':
        state.socketAuthed = true;
        setStatus(`REALTIME ONLINE · ${message.onlineCount || 1} PILOT(S)`, true);
        if (state.roomCodeToJoin) {
          const code = state.roomCodeToJoin; state.roomCodeToJoin = null;
          sendSocket({ type: 'join_room', code });
        }
        break;
      case 'auth_error':
        setStatus('AUTHENTICATION REJECTED');
        showToast(message.message || 'Server menolak autentikasi.');
        try { state.socket?.close(); } catch {}
        break;
      case 'room_state':
        state.room = message.room || null;
        renderRoom();
        break;
      case 'room_left':
        state.room = null; renderRoom(); showToast('Kamu keluar dari room.', 'success'); break;
      case 'room_error':
        showToast(message.message || 'Operasi room gagal.', 'error'); break;
      case 'room_event':
        showToast(message.message || 'Room event');
        if (message.message && /mission|match|victory|defeat|completed|failed/i.test(message.message)) $('mp-match-result').textContent = message.message;
        break;
      case 'room_invite_notice':
        showToast(`Undangan room dari ${message.fromNickname || message.fromUsername || 'teman'} diterima. Buka Notifications.`);
        refreshNotifications().catch(() => {});
        break;
      case 'invite_sent':
        showToast('Undangan room dikirim ke Notifications teman.', 'success'); break;
      case 'online_count':
        if (state.socketAuthed) setStatus(`REALTIME ONLINE · ${message.count} PILOT(S)`, true);
        break;
      case 'pong': break;
      default: break;
    }
  }

  async function handleSession(session) {
    state.session = session || null;
    state.user = session?.user || null;
    state.profile = null;
    if (!state.user) {
      state.suppressReconnect = true;
      state.socketAuthed = false;
      if (state.socket) { try { state.socket.close(); } catch {} }
      state.socket = null; state.room = null;
      setAuthVisible(false);
      return;
    }
    try {
      await loadMyProfile();
      setAuthVisible(true);
      connectSocket();
      await refreshSocialData();
    } catch (error) {
      setAuthVisible(false);
      setMessage('mp-auth-msg', error.message || String(error), 'error');
    }
  }

  async function signInOrSignUp(event) {
    event.preventDefault();
    if (!state.supa) return setMessage('mp-auth-msg', 'Supabase belum dikonfigurasi. Periksa README_ID.md dan .env.', 'error');
    const email = $('mp-email').value.trim();
    const password = $('mp-password').value;
    const submit = $('mp-auth-submit');
    submit.disabled = true;
    setMessage('mp-auth-msg', state.mode === 'signup' ? 'Membuat Pilot ID…' : 'Signing in…');
    try {
      let result;
      if (state.mode === 'signup') {
        const username = $('mp-usn').value.trim().toLowerCase();
        const nickname = $('mp-nickname').value.trim() || username;
        if (!/^[a-z0-9_]{3,20}$/.test(username)) throw new Error('USN hanya boleh huruf a-z, angka, dan underscore; panjang 3–20 karakter.');
        if (nickname.length > 24) throw new Error('Nickname maksimal 24 karakter.');
        result = await state.supa.auth.signUp({ email, password, options: { data: { username, nickname } } });
        if (result.error) throw result.error;
        if (result.data.session) {
          await handleSession(result.data.session);
          setMessage('mp-auth-msg', 'Pilot ID dibuat dan login berhasil.', 'success');
        } else {
          setMessage('mp-auth-msg', 'Pendaftaran diterima. Buka email untuk verifikasi, lalu kembali dan sign in.', 'success');
        }
      } else {
        result = await state.supa.auth.signInWithPassword({ email, password });
        if (result.error) throw result.error;
        await handleSession(result.data.session);
        setMessage('mp-auth-msg', 'Sign in berhasil.', 'success');
      }
    } catch (error) {
      const raw = error?.message || String(error);
      const readable = /profiles_username_ci|duplicate key|already exists|unique/i.test(raw)
        ? 'Username sudah dipakai. Pilih USN lain.'
        : /Database error saving new user/i.test(raw) ? 'Pendaftaran gagal. Periksa USN (harus unik), lalu pastikan schema.sql sudah dijalankan.'
        : /Invalid login credentials/i.test(raw) ? 'Email atau password tidak benar.' : raw;
      setMessage('mp-auth-msg', readable, 'error');
    } finally { submit.disabled = false; }
  }

  async function refreshSocialData() {
    if (!canUseOnline()) return;
    await Promise.allSettled([loadFriends(), loadPendingRequests(), refreshNotifications()]);
  }

  async function loadFriends() {
    const { data, error } = await state.supa.from('friendships').select('user_low,user_high').or(`user_low.eq.${state.user.id},user_high.eq.${state.user.id}`);
    if (error) { setMessage('mp-friends-msg', error.message, 'error'); return; }
    const ids = (data || []).map((row) => row.user_low === state.user.id ? row.user_high : row.user_low);
    if (!ids.length) {
      state.friends = [];
      $('mp-friend-list').innerHTML = '<div class="mp-empty">Daftar teman masih kosong. Cari username dan kirim Friend Request.</div>';
      fillInviteSelect(); return;
    }
    const profileResult = await state.supa.from('profiles').select('id,username,nickname').in('id', ids).order('username');
    if (profileResult.error) { setMessage('mp-friends-msg', profileResult.error.message, 'error'); return; }
    state.friends = profileResult.data || [];
    $('mp-friend-list').innerHTML = state.friends.map((friend) => `<div class="mp-card"><div class="mp-card-main"><div class="mp-card-name">${escapeHtml(friend.nickname || friend.username)}</div><div class="mp-handle">@${escapeHtml(friend.username)}</div></div><span class="mp-pill">FRIEND</span></div>`).join('');
    fillInviteSelect();
  }

  function fillInviteSelect() {
    const select = $('mp-invite-friend');
    const oldValue = select.value;
    if (!state.friends.length) { select.innerHTML = '<option value="">Add friends first</option>'; return; }
    select.innerHTML = '<option value="">Choose a friend…</option>' + state.friends.map((friend) => `<option value="${escapeHtml(friend.id)}">${escapeHtml(friend.nickname || friend.username)} (@${escapeHtml(friend.username)})</option>`).join('');
    if (state.friends.some((f) => f.id === oldValue)) select.value = oldValue;
  }

  async function searchPlayers(event) {
    event.preventDefault();
    if (!canUseOnline()) return;
    const query = $('mp-search-input').value.trim().toLowerCase().replace(/^@/, '');
    if (query.length < 2) return setMessage('mp-search-msg', 'Masukkan minimal 2 karakter username.');
    setMessage('mp-search-msg', 'Searching…');
    $('mp-search-results').innerHTML = '';
    const { data, error } = await state.supa.rpc('search_profiles', { p_query: query });
    if (error) return setMessage('mp-search-msg', error.message, 'error');
    const results = (data || []).filter((profile) => profile.id !== state.user.id);
    if (!results.length) return setMessage('mp-search-msg', 'Tidak ada pilot yang cocok. Username dicari berdasarkan awalan, mis. nova.');
    const friendIds = new Set(state.friends.map((f) => f.id));
    $('mp-search-results').innerHTML = results.map((p) => `<div class="mp-card"><div class="mp-card-main"><div class="mp-card-name">${escapeHtml(p.nickname || p.username)}</div><div class="mp-handle">@${escapeHtml(p.username)}</div></div>${friendIds.has(p.id) ? '<span class="mp-pill">ALREADY FRIENDS</span>' : `<button class="mp-btn primary" data-send-friend="${escapeHtml(p.username)}">ADD FRIEND</button>`}</div>`).join('');
    setMessage('mp-search-msg', `${results.length} result(s). Friend request harus diterima sebelum kalian menjadi teman.`, 'success');
  }

  async function sendFriendRequest(username) {
    setMessage('mp-search-msg', `Mengirim request ke @${username}…`);
    const { data, error } = await state.supa.rpc('request_friend', { p_username: username });
    if (error) {
      let msg = error.message || 'Request gagal.';
      if (/USER_NOT_FOUND/i.test(msg)) msg = 'Username tidak ditemukan.';
      else if (/ALREADY_FRIENDS/i.test(msg)) msg = 'Kalian sudah berteman.';
      else if (/REQUEST_PENDING/i.test(msg)) msg = 'Friend request sudah pending.';
      setMessage('mp-search-msg', msg, 'error'); return;
    }
    setMessage('mp-search-msg', 'Friend request terkirim. Menunggu penerima menekan ACCEPT.', 'success');
    refreshNotifications().catch(() => {});
  }

  async function loadPendingRequests() {
    const { data, error } = await state.supa.from('friend_requests').select('id,sender_id,created_at').eq('receiver_id', state.user.id).eq('status', 'pending').order('created_at', { ascending: false }).limit(50);
    if (error) { $('mp-pending-requests').innerHTML = `<div class="mp-empty">${escapeHtml(error.message)}</div>`; return; }
    state.pendingRequests = data || [];
    if (!data?.length) { $('mp-pending-requests').innerHTML = '<div class="mp-empty">Tidak ada permintaan yang menunggu.</div>'; return; }
    const ids = [...new Set(data.map((r) => r.sender_id))];
    const { data: profiles } = await state.supa.from('profiles').select('id,username,nickname').in('id', ids);
    const byId = new Map((profiles || []).map((p) => [p.id, p]));
    $('mp-pending-requests').innerHTML = data.map((r) => {
      const p = byId.get(r.sender_id) || { username: 'unknown', nickname: 'Unknown pilot' };
      return `<div class="mp-card"><div class="mp-card-main"><div class="mp-card-name">${escapeHtml(p.nickname || p.username)}</div><div class="mp-handle">@${escapeHtml(p.username)}</div><div class="mp-card-desc">Wants to add you as a friend.</div></div><div class="mp-actions" style="margin:0"><button class="mp-btn good" data-respond-friend="${r.id}" data-accept="true">ACCEPT</button><button class="mp-btn danger" data-respond-friend="${r.id}" data-accept="false">DECLINE</button></div></div>`;
    }).join('');
  }

  async function respondFriend(requestId, accepted) {
    const { error } = await state.supa.rpc('respond_friend_request', { p_request_id: requestId, p_accept: accepted });
    if (error) { showToast(error.message, 'error'); return; }
    showToast(accepted ? 'Friend request accepted. You are now friends.' : 'Friend request declined.', 'success');
    await Promise.allSettled([loadFriends(), loadPendingRequests(), refreshNotifications()]);
  }

  async function refreshNotifications() {
    if (!state.supa || !state.user) return;
    const { data, error } = await state.supa.from('notifications').select('id,actor_id,type,payload,is_read,created_at').eq('recipient_id', state.user.id).order('created_at', { ascending: false }).limit(50);
    if (error) { $('mp-notification-list').innerHTML = `<div class="mp-empty">${escapeHtml(error.message)}</div>`; return; }
    state.notifications = data || [];
    const unread = state.notifications.filter((n) => !n.is_read).length;
    $('mp-notification-count').textContent = unread ? `(${unread})` : '';
    if (!state.notifications.length) { $('mp-notification-list').innerHTML = '<div class="mp-empty">Tidak ada notifikasi.</div>'; return; }
    const actorIds = [...new Set(state.notifications.map((n) => n.actor_id).filter(Boolean))];
    const profileQuery = actorIds.length ? await state.supa.from('profiles').select('id,username,nickname').in('id', actorIds) : { data: [] };
    const byId = new Map((profileQuery.data || []).map((p) => [p.id, p]));
    $('mp-notification-list').innerHTML = state.notifications.map((n) => {
      const actor = byId.get(n.actor_id) || { username: 'system', nickname: 'NOVAEON SYSTEM' };
      let title = 'SYSTEM NOTIFICATION', body = 'New notification';
      if (n.type === 'friend_request') { title = 'FRIEND REQUEST'; body = `${actor.nickname || actor.username} (@${actor.username}) wants to be friends. Open Friends → Incoming Friend Requests and choose Accept or Decline.`; }
      else if (n.type === 'friend_request_accepted') { title = 'FRIEND REQUEST ACCEPTED'; body = `${actor.nickname || actor.username} (@${actor.username}) accepted your friend request.`; }
      else if (n.type === 'friend_request_declined') { title = 'FRIEND REQUEST DECLINED'; body = `${actor.nickname || actor.username} (@${actor.username}) declined your friend request.`; }
      else if (n.type === 'room_invite') { title = 'ROOM INVITATION'; body = `${actor.nickname || actor.username} (@${actor.username}) invited you to ${MAPS[n.payload?.map] || n.payload?.map || 'a map'} · ${MODES[n.payload?.mode] || n.payload?.mode || 'co-op'}. Code: ${n.payload?.roomCode || 'expired'}.`; }
      const action = n.type === 'room_invite' && n.payload?.roomCode ? `<button class="mp-btn primary" data-join-invite="${escapeHtml(n.payload.roomCode)}" data-notification-id="${n.id}">JOIN ROOM</button>` : '';
      return `<div class="mp-card" style="${n.is_read ? 'opacity:.72' : 'border-color:rgba(255,193,77,.45)'}"><div class="mp-card-main"><div class="mp-card-name">${escapeHtml(title)} ${n.is_read ? '' : '<span class="mp-pill">NEW</span>'}</div><div class="mp-card-desc">${escapeHtml(body)}</div><div class="mp-small">${escapeHtml(new Date(n.created_at).toLocaleString())}</div></div><div class="mp-actions" style="margin:0">${action}${!n.is_read ? `<button class="mp-btn" data-read-notification="${n.id}">MARK READ</button>` : ''}</div></div>`;
    }).join('');
  }

  async function markNotificationRead(id) {
    const { error } = await state.supa.from('notifications').update({ is_read: true }).eq('id', id).eq('recipient_id', state.user.id);
    if (error) { showToast(error.message, 'error'); return; }
    await refreshNotifications();
  }

  async function saveNickname() {
    const nickname = $('mp-edit-nickname').value.trim();
    if (!nickname || nickname.length > 24) return setMessage('mp-profile-msg', 'Nickname wajib 1–24 karakter.', 'error');
    const { data, error } = await state.supa.from('profiles').update({ nickname }).eq('id', state.user.id).select('id,username,nickname').single();
    if (error) return setMessage('mp-profile-msg', error.message, 'error');
    state.profile = { ...state.profile, ...data };
    setAuthVisible(true);
    setMessage('mp-profile-msg', 'Nickname updated.', 'success');
  }

  function selectTab(tab) {
    state.currentTab = tab;
    root.querySelectorAll('[data-mp-tab]').forEach((button) => button.classList.toggle('active', button.dataset.mpTab === tab));
    root.querySelectorAll('.mp-view').forEach((view) => view.classList.toggle('active', view.id === `mp-view-${tab}`));
  }

  function setRoomSelects(room) {
    $('mp-room-mode').value = room.mode;
    $('mp-room-map').value = room.map;
    $('mp-create-mode').value = room.mode;
    $('mp-create-map').value = room.map;
  }

  function renderRoom() {
    const room = state.room;
    $('mp-room-create-layout').hidden = Boolean(room);
    $('mp-room-panel').hidden = !room;
    if (!room) { state.lastRenderedRoomKey = null; return; }
    $('mp-room-code-display').textContent = room.code;
    $('mp-room-meta').textContent = `${room.phase.toUpperCase()} · ${MODES[room.mode] || room.mode} · ${MAPS[room.map] || room.map}`;
    $('mp-room-count').textContent = `${room.players.length}/6 PILOTS`;
    const roomConfigKey = `${room.code}:${room.mode}:${room.map}:${room.phase}`;
    if (state.lastRenderedRoomKey !== roomConfigKey) { setRoomSelects(room); state.lastRenderedRoomKey = roomConfigKey; }
    const me = room.players.find((p) => p.id === state.user?.id);
    const isHost = room.hostId === state.user?.id;
    $('mp-room-players').innerHTML = room.players.map((p) => `<div class="mp-player-row"><div><span class="mp-dot online"></span><strong>${escapeHtml(p.nickname || p.username)}</strong><small>@${escapeHtml(p.username)} ${p.id === room.hostId ? ' · HOST' : ''}</small></div><span class="mp-pill">${p.id === room.hostId ? 'HOST' : (p.ready ? 'READY' : 'NOT READY')}</span></div>`).join('') || '<div class="mp-empty">Waiting for players…</div>';
    $('mp-ready-btn').hidden = room.phase !== 'lobby' || isHost;
    $('mp-ready-btn').textContent = me?.ready ? 'CANCEL READY' : 'READY UP';
    $('mp-start-btn').hidden = room.phase !== 'lobby' || !isHost;
    $('mp-apply-settings').disabled = room.phase !== 'lobby' || !isHost;
    $('mp-room-mode').disabled = room.phase !== 'lobby' || !isHost;
    $('mp-room-map').disabled = room.phase !== 'lobby' || !isHost;
    $('mp-send-invite').disabled = room.phase !== 'lobby';
    $('mp-arena-wrap').hidden = room.phase === 'lobby';
    $('mp-arena-mode').textContent = MODES[room.mode] || room.mode;
    $('mp-arena-objective').textContent = room.objective || modeDescriptions[room.mode] || 'TEAM OBJECTIVE';
    $('mp-arena-timer').textContent = room.timeLeft == null ? '--:--' : `TIME ${Math.max(0, Math.ceil(room.timeLeft))}s`;
    if (room.phase === 'results') $('mp-match-result').textContent = room.result?.message || (room.result?.won ? 'MISSION COMPLETE' : 'MISSION FAILED');
    else $('mp-match-result').textContent = room.phase === 'playing' ? modeDescriptions[room.mode] || '' : '';
    if (room.phase === 'lobby') {
      $('mp-start-btn').disabled = false;
      $('mp-room-msg').textContent = isHost ? 'Host: set mode/map, invite friends, then start when ready.' : 'Set Ready after checking the mission.';
    }
  }

  function createRoom() {
    sendSocket({ type: 'create_room', mode: $('mp-create-mode').value, map: $('mp-create-map').value });
    selectTab('lobby');
  }
  function joinRoom(code) {
    const safeCode = String(code || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
    if (!/^[A-Z0-9]{6}$/.test(safeCode)) return setMessage('mp-join-msg', 'Kode room harus 6 karakter.', 'error');
    if (!state.socketAuthed) { state.roomCodeToJoin = safeCode; return setMessage('mp-join-msg', 'Menunggu koneksi realtime…'); }
    sendSocket({ type: 'join_room', code: safeCode });
    setMessage('mp-join-msg', `Joining ${safeCode}…`);
    selectTab('lobby');
  }

  async function inviteFriend() {
    const targetId = $('mp-invite-friend').value;
    if (!targetId) return showToast('Pilih teman terlebih dahulu.');
    if (!state.room) return showToast('Buat atau masuk room terlebih dahulu.');
    sendSocket({ type: 'invite_friend', targetId });
  }

  function drawArena() {
    const canvas = $('mp-arena');
    if (!canvas || $('mp-arena-wrap').hidden || !state.room) return;
    const ctx = canvas.getContext('2d');
    const room = state.room;
    const w = canvas.width, h = canvas.height;
    const palette = room.map === 'crystal_reach' ? ['#080b25','#682bbb','#42e5d1'] : room.map === 'titan_graveyard' ? ['#0d101b','#a04475','#e0bd85'] : room.map === 'derelict_station' ? ['#061b21','#168c8b','#9affdf'] : ['#02030e','#4c50a7','#f0c4ff'];
    const bg = ctx.createLinearGradient(0,0,w,h); bg.addColorStop(0,palette[0]); bg.addColorStop(1,'#02050d'); ctx.fillStyle=bg; ctx.fillRect(0,0,w,h);
    // Deterministic starfield: no network assets needed.
    for (let i=0;i<105;i++) { const x=(i*173+31)%w, y=(i*97+11)%h; ctx.globalAlpha=.22+(i%7)*.09; ctx.fillStyle=i%8===0?palette[2]:'#dceeff'; ctx.fillRect(x,y,i%8===0?2:1,i%8===0?2:1); }
    ctx.globalAlpha=1;
    ctx.strokeStyle='rgba(100,175,235,.09)'; ctx.lineWidth=1;
    for(let x=0;x<=w;x+=100){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();}
    for(let y=0;y<=h;y+=100){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}

    if (room.mode === 'crystal_salvage') {
      ctx.save(); ctx.strokeStyle='#63ffd1'; ctx.fillStyle='rgba(45,255,194,.08)'; ctx.lineWidth=3; ctx.setLineDash([8,8]); ctx.beginPath(); ctx.arc(w-95,h-88,66,0,Math.PI*2); ctx.fill(); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle='#8affdc'; ctx.font='bold 15px monospace'; ctx.fillText('EXTRACTION',w-153,h-5); ctx.restore();
      for(const crystal of room.crystals || []) { ctx.save(); ctx.translate(crystal.x,crystal.y); ctx.rotate((performance.now()/900)+(crystal.id.length%4)); ctx.shadowBlur=16; ctx.shadowColor=palette[2]; ctx.fillStyle=palette[2]; ctx.beginPath(); ctx.moveTo(0,-13);ctx.lineTo(9,-2);ctx.lineTo(5,10);ctx.lineTo(-6,8);ctx.lineTo(-10,-3);ctx.closePath();ctx.fill();ctx.restore(); }
    }
    if (room.mode === 'convoy_defense') {
      const cx=w/2,cy=h/2;
      ctx.save(); ctx.strokeStyle='#ffc66e';ctx.lineWidth=2;ctx.shadowBlur=18;ctx.shadowColor='#ffc66e';ctx.beginPath();ctx.moveTo(cx-35,cy-28);ctx.lineTo(cx+35,cy-28);ctx.lineTo(cx+52,cy);ctx.lineTo(cx+35,cy+28);ctx.lineTo(cx-35,cy+28);ctx.lineTo(cx-52,cy);ctx.closePath();ctx.stroke();ctx.fillStyle='rgba(255,180,80,.1)';ctx.fill();ctx.fillStyle='#ffe6b5';ctx.font='bold 12px monospace';ctx.fillText(`CONVOY ${Math.max(0,Math.round(room.convoyHP||0))}%`,cx-48,cy+52);ctx.restore();
      for(const enemy of room.enemies || []) { ctx.save();ctx.translate(enemy.x,enemy.y);ctx.rotate(Math.PI/4);ctx.shadowBlur=12;ctx.shadowColor='#ff557d';ctx.fillStyle='#ff557d';ctx.fillRect(-9,-9,18,18);ctx.restore(); }
    }
    if (room.mode === 'reactor_breach') {
      (room.nodes || []).forEach((node,i)=>{ctx.save();ctx.beginPath();ctx.arc(node.x,node.y,node.active?25:34,0,Math.PI*2);ctx.strokeStyle=node.active?'#65ffaf':(i===room.activeNode?'#ffc14d':'#476280');ctx.lineWidth=node.active?5:2;ctx.shadowBlur=node.active?18:5;ctx.shadowColor=ctx.strokeStyle;ctx.stroke();ctx.fillStyle=node.active?'#65ffaf':'#7b9abd';ctx.font='bold 12px monospace';ctx.fillText(node.active?'ONLINE':`NODE ${i+1}`,node.x-28,node.y+52);ctx.restore();});
    }

    for (const p of room.players || []) {
      const isMe = p.id === state.user?.id;
      ctx.save(); ctx.translate(p.x,p.y); ctx.shadowBlur=isMe?22:12; ctx.shadowColor=isMe?'#48eeff':'#ae8aff';
      ctx.fillStyle=isMe?'#42eaff':'#bda2ff'; ctx.strokeStyle=isMe?'#f1feff':'#e9dbff';ctx.lineWidth=2;
      ctx.beginPath();ctx.moveTo(0,-15);ctx.lineTo(11,10);ctx.lineTo(0,6);ctx.lineTo(-11,10);ctx.closePath();ctx.fill();ctx.stroke();ctx.shadowBlur=0;
      ctx.fillStyle='#f1f7ff';ctx.font='bold 10px monospace';ctx.textAlign='center';ctx.fillText((p.nickname||p.username||'PILOT').slice(0,15),0,-23);
      if(room.mode==='crystal_salvage'&&p.cargo>0){ctx.fillStyle='#6dffb8';ctx.fillText(`◆${p.cargo}`,0,25);}
      ctx.restore();
    }
    if(room.phase==='results'){ctx.fillStyle='rgba(1,4,12,.75)';ctx.fillRect(0,0,w,h);ctx.textAlign='center';ctx.fillStyle=room.result?.won?'#6dffb8':'#ff799b';ctx.font='900 42px sans-serif';ctx.fillText(room.result?.won?'MISSION COMPLETE':'MISSION FAILED',w/2,h/2);ctx.fillStyle='#e8f2ff';ctx.font='16px monospace';ctx.fillText(room.result?.message||'Return to lobby to play again.',w/2,h/2+34);}
    ctx.textAlign='left';
  }

  function sendMovementInput(now) {
    if (!state.room || state.room.phase !== 'playing' || !state.socketAuthed || now - state.lastInputAt < 60) return;
    state.lastInputAt = now;
    let x = 0, y = 0;
    const pressed = (k) => state.keys.has(k);
    if (pressed('a') || pressed('arrowleft') || state.touchDirections.has('left')) x -= 1;
    if (pressed('d') || pressed('arrowright') || state.touchDirections.has('right')) x += 1;
    if (pressed('w') || pressed('arrowup') || state.touchDirections.has('up')) y -= 1;
    if (pressed('s') || pressed('arrowdown') || state.touchDirections.has('down')) y += 1;
    const mag = Math.hypot(x,y); if(mag>1){x/=mag;y/=mag;}
    sendSocket({type:'input',x,y});
  }

  function animationFrame(now) {
    sendMovementInput(now);
    drawArena();
    requestAnimationFrame(animationFrame);
  }

  function wireUI() {
    $('btn-multiplayer')?.addEventListener('click', () => { showRoot(); selectTab(canUseOnline() ? state.currentTab : 'friends'); });
    $('mp-close').addEventListener('click', hideRoot);
    $('mp-auth-form').addEventListener('submit', signInOrSignUp);
    $('mp-toggle-signup').addEventListener('click', () => switchAuthMode(state.mode === 'signup' ? 'signin' : 'signup'));
    $('mp-signout').addEventListener('click', async () => { if (state.supa) await state.supa.auth.signOut(); });
    $('mp-search-form').addEventListener('submit', searchPlayers);
    $('mp-search-results').addEventListener('click', (event) => { const button = event.target.closest('[data-send-friend]'); if(button) sendFriendRequest(button.dataset.sendFriend); });
    $('mp-pending-requests').addEventListener('click', (event) => { const button = event.target.closest('[data-respond-friend]'); if(button) respondFriend(button.dataset.respondFriend, button.dataset.accept === 'true'); });
    $('mp-notification-list').addEventListener('click', (event) => {
      const join = event.target.closest('[data-join-invite]');
      const mark = event.target.closest('[data-read-notification]');
      if (join) { selectTab('lobby'); joinRoom(join.dataset.joinInvite); if (join.dataset.notificationId) markNotificationRead(join.dataset.notificationId).catch(()=>{}); }
      if (mark) markNotificationRead(mark.dataset.readNotification).catch(()=>{});
    });
    root.querySelectorAll('[data-mp-tab]').forEach((button) => button.addEventListener('click', () => selectTab(button.dataset.mpTab)));
    $('mp-refresh-notifications').addEventListener('click', () => refreshSocialData());
    $('mp-save-nickname').addEventListener('click', () => saveNickname());
    $('mp-create-room').addEventListener('click', createRoom);
    $('mp-join-form').addEventListener('submit', (event) => { event.preventDefault(); joinRoom($('mp-join-code').value); });
    $('mp-copy-code').addEventListener('click', async () => { if (!state.room) return; try { await navigator.clipboard.writeText(state.room.code); showToast('Room code copied.', 'success'); } catch { showToast(`Share code manually: ${state.room.code}`); } });
    $('mp-leave-room').addEventListener('click', () => sendSocket({type:'leave_room'}));
    $('mp-ready-btn').addEventListener('click', () => { const me=state.room?.players.find((p)=>p.id===state.user?.id); sendSocket({type:'set_ready',ready:!me?.ready}); });
    $('mp-start-btn').addEventListener('click', () => sendSocket({type:'start_match'}));
    $('mp-apply-settings').addEventListener('click', () => sendSocket({type:'set_settings',mode:$('mp-room-mode').value,map:$('mp-room-map').value}));
    $('mp-send-invite').addEventListener('click', inviteFriend);
    $('mp-action-btn').addEventListener('click', () => sendSocket({type:'action'}));
    document.addEventListener('keydown', (event) => {
      if (!root.classList.contains('open') || !state.room || state.room.phase !== 'playing') return;
      const tag = event.target?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      const key = event.key.toLowerCase();
      if (['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright',' '].includes(key)) event.preventDefault();
      if (key === ' ' && !state.keys.has('__action-lock')) {
        state.keys.add('__action-lock'); sendSocket({type:'action'}); return;
      }
      state.keys.add(key);
    });
    document.addEventListener('keyup', (event) => {
      const key = event.key.toLowerCase(); state.keys.delete(key);
      if (key === ' ') state.keys.delete('__action-lock');
    });
    window.addEventListener('blur', () => { state.keys.clear(); state.touchDirections.clear(); });
    root.querySelectorAll('[data-mp-dir]').forEach((button) => {
      const dir = button.dataset.mpDir;
      const down = (event) => { event.preventDefault(); state.touchDirections.add(dir); };
      const up = (event) => { event.preventDefault(); state.touchDirections.delete(dir); };
      button.addEventListener('pointerdown', down);
      ['pointerup','pointercancel','pointerleave'].forEach((type) => button.addEventListener(type, up));
      button.addEventListener('contextmenu', (e) => e.preventDefault());
    });
    root.addEventListener('click', (event) => { if (event.target === root) hideRoot(); });
    window.addEventListener('beforeunload', () => { try { state.socket?.close(); } catch {} });
  }

  async function checkServerHealth() {
    try {
      const response = await fetch('/api/health', { cache: 'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const health = await response.json();
      state.serverReady = Boolean(health.supabaseConfigured);
      if (!state.serverReady) {
        $('mp-config-notice').hidden = false;
        $('mp-config-notice').textContent = 'Node.js berjalan, tetapi URL/key Supabase (termasuk server secret/service role) belum lengkap di .env. Auth UI perlu public key; room realtime perlu konfigurasi server juga.';
        setStatus('SERVER RUNNING · SUPABASE SERVER KEY MISSING');
      } else {
        if (state.supa) $('mp-config-notice').hidden = true;
        setStatus('SERVER READY · SIGN IN TO GO ONLINE');
        if (state.session && !state.socket) connectSocket();
      }
    } catch (error) {
      state.serverReady = false;
      $('mp-config-notice').hidden = false;
      $('mp-config-notice').textContent = 'Tidak bisa menghubungi endpoint Node.js. Buka game melalui http://localhost:2567 dan pastikan npm start masih berjalan.';
      setStatus('NODE SERVER UNREACHABLE');
    }
  }

  function init() {
    const cfg = window.NOVAEON_CONFIG || {};
    if (!cfg.supabaseUrl || !cfg.supabaseAnonKey || !window.supabase?.createClient) {
      $('mp-config-notice').hidden = false;
      setStatus('CONFIGURATION REQUIRED');
    } else {
      try {
        state.supa = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
        $('mp-config-notice').hidden = true;
        setStatus('SUPABASE READY · SIGN IN TO GO ONLINE');
        state.supa.auth.getSession().then(({data}) => handleSession(data.session)).catch((error) => setMessage('mp-auth-msg', error.message, 'error'));
        state.supa.auth.onAuthStateChange((_event, session) => {
          // Defer DB access to avoid holding Supabase's auth lock during callback execution.
          window.setTimeout(() => handleSession(session), 0);
        });
        window.setInterval(() => { if (canUseOnline()) refreshSocialData().catch(() => {}); }, 7000);
      } catch (error) {
        setStatus('SUPABASE INITIALIZATION FAILED');
        setMessage('mp-auth-msg', error.message, 'error');
      }
    }
    wireUI();
    checkServerHealth();
    window.setInterval(checkServerHealth, 12000);
    requestAnimationFrame(animationFrame);
  }
  switchAuthMode('signin');
  init();
})();
