# NOVAEON Online Multiplayer Alpha — panduan menjalankan

Paket ini menggunakan **HTML NOVAEON yang kamu unggah sebagai game dasar**, kemudian menambahkan panel Multiplayer terpisah agar campaign solo, Garage, Achievement, dan sistem lain tidak diganti.

## Fitur yang ada di MVP ini

- Pilot ID dengan email/password Supabase Auth.
- Username unik global, hanya huruf kecil `a-z`, angka, dan underscore, panjang 3–20; username disimpan lowercase dan tidak bisa diubah lewat UI.
- Nickname terpisah (1–24 karakter) dan dapat diubah.
- Search username berdasarkan awalan, Add Friend, status Pending, dan Accept/Decline melalui Notifications/Friends dalam game.
- Friend list dan undangan room yang tersimpan di tabel Notifications.
- Room real-time maksimal 6 pemain, room code 6 karakter, host, mode/map pilihan host, ready check, invite friend, dan Start Mission.
- Tiga mode co-op prototipe: Crystal Salvage, Convoy Defense, dan Reactor Breach.
- Empat pilihan latar/map: Crystal Reach, Titan Graveyard, Derelict Station, dan Deep Void.
- Movement keyboard dan tombol sentuh, simulasi objektif serta state room dikelola Node.js.
- Campaign solo tetap terpisah. Reward pertandingan multiplayer saat ini belum dimasukkan ke Credits/EXP campaign.

**Ini adalah alpha lokal yang siap dikonfigurasi, bukan layanan publik yang sudah di-host.** Teman di perangkat lain tidak bisa masuk ke server lokalmu melalui internet sebelum server di-deploy ke host publik dan koneksi WSS/firewall diatur. Supabase, Node.js server, dan browser harus dikonfigurasi dulu.

## 1. Persiapan

1. Pasang **Node.js 22 LTS atau yang lebih baru**.
2. Buka folder `NOVAEON_Online_Multiplayer` di VS Code.
3. Pastikan terminal berada di folder yang berisi `package.json`.
4. Buat proyek di Supabase (layanan database dan autentikasi online). Jangan memakai kunci rahasia di HTML.

## 2. Siapkan database Supabase

1. Buka Supabase Dashboard, pilih proyek, lalu buka **SQL Editor**.
2. Buka file `supabase/schema.sql` di VS Code.
3. Salin seluruh SQL ke SQL Editor dan jalankan sekali.
4. Buka **Project Settings / API** atau halaman **Connect**. Salin Project URL dan public publishable/anon key.
5. Ambil server secret/service-role key untuk konfigurasi Node.js saja. **Jangan taruh key ini dalam HTML, jangan commit `.env` ke GitHub, dan jangan kirimkan key itu ke siapa pun.**
6. Pastikan konfigurasi email Supabase sesuai kebutuhan. Bila verifikasi email aktif, pemain harus mengonfirmasi email sebelum sign in.

SQL membuat tabel `profiles`, `friend_requests`, `friendships`, `notifications`, RLS policies, serta fungsi RPC. Unique index di database menjadi penentu username, bukan validasi browser.

## 3. Konfigurasi Node.js

Di terminal VS Code, jalankan:

```bash
npm install
```

Salin `.env.example` menjadi `.env` di folder project yang sama dengan `package.json`. Isi:

```dotenv
PORT=2567
SUPABASE_URL=https://PROJECT_ID_KAMU.supabase.co
SUPABASE_ANON_KEY=PUBLIC_PUBLISHABLE_ATAU_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY=SERVER_SECRET_KEY
PUBLIC_WS_URL=
```

Catatan:
- `SUPABASE_URL` dan public key dipakai untuk klien Auth/database. Public key memang akan disajikan ke browser.
- `SUPABASE_SERVICE_ROLE_KEY` hanya digunakan oleh Node.js server untuk memverifikasi token, memeriksa pertemanan, dan menyimpan undangan. Kunci ini melewati RLS, sehingga **wajib dirahasiakan**.
- Biarkan `PUBLIC_WS_URL` kosong saat menguji lokal. Bila server nanti di-deploy di domain terpisah, isi dengan origin publik server (misalnya `wss://game-server.example.com`, tanpa `/multiplayer`). Server publik harus menggunakan HTTPS/WSS.

## 4. Jalankan game dan server

Jalankan:

```bash
npm start
```

Buka browser ke:

`http://localhost:2567`

Jangan membuka `public/index.html` lewat `file://`; halaman harus dilayani Node agar `/runtime-config.js` dan WebSocket berfungsi.

Periksa status server:

`http://localhost:2567/api/health`

Nilai `supabaseConfigured` harus `true`. Jika `false`, periksa nama file `.env`, nilai yang diisi, lalu restart `npm start`.

## 5. Tes dua akun / dua browser

1. Buka NOVAEON pada dua browser profile atau satu jendela normal dan satu incognito.
2. Daftarkan dua Pilot ID dengan email yang berbeda dan username berbeda. Selesaikan verifikasi email bila diminta.
3. Pada akun A, pilih Multiplayer → Search Pilot, cari username akun B, lalu Add Friend.
4. Pada akun B, buka Multiplayer → Friends → Incoming Friend Requests dan tekan Accept.
5. Kembali ke A, buat room. Salin kode room dan kirim ke B, atau gunakan Invite A Friend dari lobby.
6. Buka Lobby pada akun B, lalu Join Room memakai kode. Coba pilih mode/map (host only), READY, dan START.
7. Crystal Salvage: gerakkan kapal ke kristal, lalu kembali ke lingkaran Extraction dan tekan ACTION untuk menyetor. Tim butuh 12 kristal.
8. Convoy Defense: bertahan 90 detik, dekati drone merah, lalu tekan ACTION untuk mengirim pulse.
9. Reactor Breach: kunjungi node berurutan dan tekan ACTION saat dekat node.

Untuk kontrol keyboard: **WASD / Arrow keys**. Tombol arah di panel permainan mendukung sentuhan. Tombol ACTION juga dapat digunakan dengan Space.

## 6. Commit aman ke GitHub

Simpan source seperti biasa, tetapi pastikan `.env` tidak ter-commit. `.gitignore` sudah berisi aturan untuk `.env` dan `node_modules`. File `.env.example` boleh masuk repository karena hanya berisi placeholder.

## Struktur proyek

```text
NOVAEON_Online_Multiplayer/
├── public/
│   ├── index.html             # HTML game kamu + tombol/panel multiplayer
│   └── js/multiplayer.js      # auth, friends, notifications, room UI, co-op client
├── server/index.js            # Express + WebSocket + room simulation
├── supabase/schema.sql        # tables, unique USN, RLS, RPC
├── .env.example               # template konfigurasi, tanpa secret
├── .gitignore
├── package.json
└── README_ID.md
```

## Batasan MVP yang disengaja

- Room disimpan di memori proses Node.js. Jika server restart, room aktif akan hilang; akun, pertemanan, dan notifikasi yang disimpan di Supabase tetap ada.
- Room ini hanya melayani hingga 6 pemain. Untuk production perlu room reconciliation, reconnection token, rate limits lebih ketat, logging, moderation/reporting, dan deployment TLS/WSS.
- Akun dan pertemanan online belum menggabungkan save solo/garage ke backend; progres multiplayer belum memberi Credits/EXP campaign agar pemain tidak dapat memalsukan reward melalui klien.
- Saat ini sistem gerak dan objektif kooperatif menggunakan arena 2D multiplayer baru. Ia tidak menyinkronkan semua projectile/AI dari campaign solo. Ini jalur aman untuk membuat satu mode co-op dulu tanpa merusak simulasinya.
- Game masih berupa source yang bisa diedit pengguna. Node.js menegakkan room state dasar, tetapi sebelum public release perlu validasi tambahan untuk seluruh input dan anti-abuse.

## Troubleshooting

- **Supabase belum dikonfigurasi:** cek `.env` dan restart Node.
- **Profil tidak ditemukan setelah sign up:** pastikan `supabase/schema.sql` sudah dijalankan; jika akun dibuat sebelum trigger aktif, untuk alpha ini buat akun baru setelah schema siap.
- **Username sudah dipakai:** pilih username lain; uniqueness diperiksa database.
- **Socket auth error:** pastikan service role key benar, profil tersedia, lalu sign out/sign in.
- **Teman tidak menerima room invite:** pastikan friend request sudah accepted, target mengundang dari room lobby, dan lihat Notifications. Notifikasi room tersimpan walau teman sedang offline, tetapi kode tidak berlaku jika room sudah ditutup.
- **Teman dari perangkat lain tidak bisa connect:** local server hanya bisa diakses dari komputer yang menjalankannya kecuali di-deploy / diproxy ke internet. Jangan membuka port publik tanpa HTTPS/WSS, rate limit, dan konfigurasi deployment yang benar.
