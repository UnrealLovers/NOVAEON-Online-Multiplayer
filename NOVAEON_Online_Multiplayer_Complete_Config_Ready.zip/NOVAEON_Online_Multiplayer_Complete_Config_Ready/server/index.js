import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';
import { createClient } from '@supabase/supabase-js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(__dirname, '..');
const publicDir = path.join(rootDir, 'public');
const PORT = Number(process.env.PORT || 2567);
const SUPABASE_URL = process.env.SUPABASE_URL || '';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || '';
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const supabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY && SUPABASE_SERVICE_ROLE_KEY);
const admin = supabaseConfigured ? createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false }
}) : null;

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '24kb' }));
app.get('/runtime-config.js', (_req, res) => {
  res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(`window.NOVAEON_CONFIG = ${JSON.stringify({
    supabaseUrl: SUPABASE_URL,
    supabaseAnonKey: SUPABASE_ANON_KEY,
    wsUrl: process.env.PUBLIC_WS_URL || ''
  })};`);
});
app.get('/api/health', (_req, res) => res.json({
  ok: true,
  service: 'novaeon-online',
  supabaseConfigured,
  onlinePilots: online.size,
  activeRooms: rooms.size,
  maxPlayersPerRoom: 6
}));
app.use(express.static(publicDir, { extensions: ['html'] }));
app.use((_req, res) => res.sendFile(path.join(publicDir, 'index.html')));

const httpServer = http.createServer(app);
const wss = new WebSocketServer({ noServer: true, maxPayload: 24 * 1024 });
const rooms = new Map(); // room code -> room data
const online = new Map(); // user id -> Set<WebSocket>
const MODES = new Set(['crystal_salvage', 'convoy_defense', 'reactor_breach']);
const MAPS = new Set(['crystal_reach', 'titan_graveyard', 'derelict_station', 'deep_void']);
const W = 1000, H = 600;

function send(ws, data) {
  if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}
function sendError(ws, message) { send(ws, { type: 'room_error', message }); }
function sendEvent(room, message) { roomBroadcast(room, { type: 'room_event', message }); }
function onlineCount() { return online.size; }
function addOnline(userId, ws) {
  if (!online.has(userId)) online.set(userId, new Set());
  online.get(userId).add(ws);
}
function removeOnline(userId, ws) {
  const set = online.get(userId);
  if (!set) return;
  set.delete(ws);
  if (!set.size) online.delete(userId);
}
function sendToUser(userId, payload) {
  for (const ws of online.get(userId) || []) send(ws, payload);
}
function newCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (let attempt = 0; attempt < 100; attempt++) {
    let code = '';
    for (let i = 0; i < 6; i++) code += alphabet[Math.floor(Math.random() * alphabet.length)];
    if (!rooms.has(code)) return code;
  }
  throw new Error('Unable to allocate a room code. Try again.');
}
function playerFrom(socket) {
  const p = socket.roomCode && rooms.get(socket.roomCode)?.players.get(socket.user?.id);
  return p || null;
}
function distance(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }
function randomPoint(margin = 45) { return { x: margin + Math.random() * (W - 2 * margin), y: margin + Math.random() * (H - 2 * margin) }; }
function spawnCrystal() {
  let p;
  for (let i = 0; i < 25; i++) {
    p = randomPoint(44);
    if (distance(p, { x: W - 95, y: H - 88 }) > 115) break;
  }
  return { id: `c${Math.random().toString(36).slice(2, 10)}`, x: p.x, y: p.y };
}
function playerObject(profile, isHost = false) {
  const pos = randomPoint(90);
  return {
    id: profile.id, username: profile.username, nickname: profile.nickname || profile.username,
    x: pos.x, y: pos.y, cargo: 0, score: 0, ready: Boolean(isHost),
    input: { x: 0, y: 0 }, actionCooldown: 0, lastInputAt: 0
  };
}
function getRoomFromSocket(socket) {
  const room = socket.roomCode ? rooms.get(socket.roomCode) : null;
  if (!room) socket.roomCode = null;
  return room;
}
function snapshot(room) {
  return {
    code: room.code, hostId: room.hostId, mode: room.mode, map: room.map, phase: room.phase,
    players: [...room.players.values()].map((p) => ({ id: p.id, username: p.username, nickname: p.nickname, x: p.x, y: p.y, cargo: p.cargo, score: p.score, ready: p.ready })),
    crystals: room.crystals, enemies: room.enemies, nodes: room.nodes, activeNode: room.activeNode,
    delivered: room.delivered, goal: room.goal, convoyHP: room.convoyHP, timeLeft: room.timeLeft,
    objective: room.objective, result: room.result
  };
}
function roomBroadcast(room, payload) {
  for (const player of room.players.values()) send(player.socket, payload);
}
function broadcastRoom(room) { roomBroadcast(room, { type: 'room_state', room: snapshot(room) }); }
function pushSnapshot(room) { broadcastRoom(room); }
function findSocketUser(userId) {
  const set = online.get(userId);
  if (!set) return null;
  for (const ws of set) if (ws.readyState === WebSocket.OPEN && ws.user?.id === userId) return ws;
  return null;
}
async function getProfile(userId) {
  if (!admin) throw new Error('Server Supabase belum dikonfigurasi. Isi .env dengan URL dan service role key.');
  const { data, error } = await admin.from('profiles').select('id,username,nickname').eq('id', userId).maybeSingle();
  if (error) throw error;
  if (!data) throw new Error('Profil tidak ditemukan. Jalankan supabase/schema.sql dan daftar ulang jika akun dibuat sebelum schema.');
  return data;
}
async function verifyToken(token) {
  if (!admin) throw new Error('Server Supabase belum dikonfigurasi. Isi .env terlebih dahulu.');
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data?.user) throw new Error('Session tidak valid atau sudah kedaluwarsa. Sign in kembali.');
  const profile = await getProfile(data.user.id);
  return { authUser: data.user, profile };
}
async function isFriend(userA, userB) {
  if (!admin) return false;
  const [low, high] = [userA, userB].sort();
  const { data, error } = await admin.from('friendships').select('user_low,user_high').eq('user_low', low).eq('user_high', high).maybeSingle();
  if (error) throw error;
  return Boolean(data);
}
async function createNotification({ recipientId, actorId, type, payload }) {
  if (!admin) throw new Error('Supabase admin client is not configured.');
  const { error } = await admin.from('notifications').insert({ recipient_id: recipientId, actor_id: actorId, type, payload, is_read: false });
  if (error) throw error;
}
function createRoom(profile, mode, map) {
  const code = newCode();
  const host = playerObject(profile, true);
  const room = {
    code, hostId: profile.id, mode: MODES.has(mode) ? mode : 'crystal_salvage',
    map: MAPS.has(map) ? map : 'crystal_reach', phase: 'lobby', players: new Map([[profile.id, host]]),
    crystals: [], enemies: [], nodes: [], activeNode: 0, delivered: 0, goal: 12, convoyHP: 100,
    timeLeft: 0, objective: 'Waiting for pilots', result: null,
    clock: 0, spawnClock: 0, tickClock: 0, createdAt: Date.now()
  };
  rooms.set(code, room);
  return room;
}
function findRoomByPlayer(userId) {
  for (const room of rooms.values()) if (room.players.has(userId)) return room;
  return null;
}
function leaveRoom(ws, notify = true) {
  const room = getRoomFromSocket(ws);
  const userId = ws.user?.id;
  if (!room || !userId) { ws.roomCode = null; return; }
  const p = room.players.get(userId);
  if (p && p.socket === ws) room.players.delete(userId);
  ws.roomCode = null;
  if (!room.players.size) {
    rooms.delete(room.code);
    if (notify) send(ws, { type: 'room_left' });
    return;
  }
  if (room.hostId === userId) {
    const nextHost = room.players.values().next().value;
    room.hostId = nextHost.id;
    nextHost.ready = true;
    sendEvent(room, `${nextHost.nickname} is now host.`);
  }
  broadcastRoom(room);
  if (notify) send(ws, { type: 'room_left' });
}
function beginMatch(room) {
  if (room.phase !== 'lobby') throw new Error('Match sudah berjalan.');
  const notReady = [...room.players.values()].filter((p) => p.id !== room.hostId && !p.ready);
  if (notReady.length) throw new Error('Semua pemain selain host harus menekan READY UP.');
  room.phase = 'playing'; room.result = null; room.clock = 0; room.spawnClock = 0; room.tickClock = 0;
  room.delivered = 0; room.goal = 12; room.convoyHP = 100; room.activeNode = 0; room.enemies = [];
  room.timeLeft = room.mode === 'convoy_defense' ? 90 : room.mode === 'reactor_breach' ? 150 : 180;
  room.objective = room.mode === 'crystal_salvage' ? 'Collect 12 crystals and deposit at extraction' : room.mode === 'convoy_defense' ? 'Defend the convoy for 90 seconds' : 'Activate all 3 reactor nodes in order';
  for (const p of room.players.values()) {
    Object.assign(p, { ...randomPoint(70), cargo: 0, score: 0, input: { x: 0, y: 0 }, actionCooldown: 0 });
  }
  room.crystals = room.mode === 'crystal_salvage' ? Array.from({ length: 8 }, () => spawnCrystal()) : [];
  room.nodes = room.mode === 'reactor_breach' ? [{ x: 170, y: 170, active: false }, { x: 500, y: 410, active: false }, { x: 830, y: 170, active: false }] : [];
  sendEvent(room, `MISSION STARTED · ${room.mode.replaceAll('_', ' ').toUpperCase()} / ${room.map.replaceAll('_', ' ').toUpperCase()}`);
  broadcastRoom(room);
}
function finishMatch(room, won, message) {
  if (room.phase !== 'playing') return;
  room.phase = 'results'; room.result = { won: Boolean(won), message, delivered: room.delivered, convoyHP: room.convoyHP };
  room.objective = won ? 'Team objective completed' : 'The team objective was not completed';
  broadcastRoom(room);
  sendEvent(room, message);
}
function doAction(room, player) {
  if (room.phase !== 'playing' || player.actionCooldown > 0) return;
  player.actionCooldown = 0.65;
  if (room.mode === 'crystal_salvage') {
    const extraction = { x: W - 95, y: H - 88 };
    if (distance(player, extraction) > 78) {
      send(player.socket, { type: 'room_event', message: 'Reach the green Extraction ring before using ACTION to deposit cargo.' });
      return;
    }
    if (!player.cargo) {
      send(player.socket, { type: 'room_event', message: 'Cargo hold is empty. Collect a crystal first.' });
      return;
    }
    const deposited = player.cargo;
    player.cargo = 0; player.score += deposited * 100; room.delivered += deposited;
    sendEvent(room, `${player.nickname} deposited ${deposited} crystal(s) · ${Math.min(room.delivered, room.goal)}/${room.goal}`);
    if (room.delivered >= room.goal) finishMatch(room, true, 'CRYSTAL SALVAGE COMPLETE — TEAM EXTRACTION SUCCESSFUL');
  } else if (room.mode === 'convoy_defense') {
    let closest = null, closestDistance = 150;
    for (const enemy of room.enemies) { const d = distance(player, enemy); if (d < closestDistance) { closest = enemy; closestDistance = d; } }
    if (!closest) { send(player.socket, { type: 'room_event', message: 'No drone in pulse range. Move closer to an enemy.' }); return; }
    room.enemies = room.enemies.filter((enemy) => enemy.id !== closest.id);
    player.score += 150;
    sendEvent(room, `${player.nickname} eliminated a hostile drone.`);
  } else if (room.mode === 'reactor_breach') {
    const node = room.nodes[room.activeNode];
    if (!node) { send(player.socket, { type: 'room_event', message: 'All reactor nodes are already online.' }); return; }
    if (distance(player, node) > 75) { send(player.socket, { type: 'room_event', message: `Move closer to REACTOR NODE ${room.activeNode + 1}.` }); return; }
    node.active = true; player.score += 250; room.activeNode += 1;
    sendEvent(room, `${player.nickname} activated reactor node ${room.activeNode}/3.`);
    if (room.activeNode >= room.nodes.length) finishMatch(room, true, 'REACTOR BREACH COMPLETE — ALL NODES ONLINE');
  }
}
function makeEnemy() {
  const side = Math.floor(Math.random() * 4);
  return { id: `e${Math.random().toString(36).slice(2, 9)}`, x: side === 0 ? 20 : side === 1 ? W - 20 : 70 + Math.random() * (W - 140), y: side === 2 ? 20 : side === 3 ? H - 20 : 60 + Math.random() * (H - 120), speed: 34 + Math.random() * 24 };
}
function tickRoom(room, dt) {
  if (room.phase !== 'playing') return;
  room.clock += dt; room.timeLeft = Math.max(0, room.timeLeft - dt); room.spawnClock += dt;
  for (const player of room.players.values()) {
    player.actionCooldown = Math.max(0, player.actionCooldown - dt);
    if (Date.now() - (player.lastInputAt || 0) > 450) player.input = { x: 0, y: 0 };
    const ix = player.input.x, iy = player.input.y;
    const speed = 210;
    player.x = Math.max(24, Math.min(W - 24, player.x + ix * speed * dt));
    player.y = Math.max(24, Math.min(H - 24, player.y + iy * speed * dt));
  }
  if (room.mode === 'crystal_salvage') {
    for (const player of room.players.values()) {
      for (let i = room.crystals.length - 1; i >= 0; i--) {
        if (player.cargo < 5 && distance(player, room.crystals[i]) < 23) {
          room.crystals.splice(i, 1); player.cargo += 1; player.score += 10;
          send(player.socket, { type: 'room_event', message: 'CRYSTAL COLLECTED · Return to Extraction.' });
        }
      }
    }
    if (room.crystals.length < 8 && room.delivered + [...room.players.values()].reduce((a,p)=>a+p.cargo,0) < room.goal && room.spawnClock > 1.2) {
      room.crystals.push(spawnCrystal()); room.spawnClock = 0;
    }
  } else if (room.mode === 'convoy_defense') {
    if (room.spawnClock > 2.4 && room.enemies.length < 16) { room.enemies.push(makeEnemy()); room.spawnClock = 0; }
    const convoy = { x: W / 2, y: H / 2 };
    for (let i = room.enemies.length - 1; i >= 0; i--) {
      const enemy = room.enemies[i]; const dx = convoy.x - enemy.x, dy = convoy.y - enemy.y; const length = Math.hypot(dx,dy) || 1;
      enemy.x += dx / length * enemy.speed * dt; enemy.y += dy / length * enemy.speed * dt;
      if (length < 28) { room.convoyHP = Math.max(0, room.convoyHP - 8); room.enemies.splice(i,1); }
    }
    if (room.convoyHP <= 0) finishMatch(room, false, 'CONVOY LOST — THE TEAM COULD NOT HOLD THE LINE');
  }
  if (room.timeLeft <= 0 && room.phase === 'playing') {
    if (room.mode === 'convoy_defense' && room.convoyHP > 0) finishMatch(room, true, 'CONVOY DEFENDED — SURVIVED 90 SECONDS');
    else finishMatch(room, false, room.mode === 'crystal_salvage' ? 'EXTRACTION WINDOW CLOSED — NOT ENOUGH CRYSTALS DELIVERED' : room.mode === 'reactor_breach' ? 'REACTOR LOCKDOWN — NODES REMAIN INACTIVE' : 'MISSION TIMER EXPIRED');
  }
  room.tickClock += dt;
  if (room.tickClock >= 0.1) { room.tickClock = 0; broadcastRoom(room); }
}

async function handleMessage(ws, raw) {
  if (raw.length > 20 * 1024) return sendError(ws, 'Message too large.');
  let msg;
  try { msg = JSON.parse(raw.toString()); } catch { return sendError(ws, 'Invalid JSON message.'); }
  if (!msg || typeof msg.type !== 'string') return sendError(ws, 'Invalid message type.');

  if (msg.type === 'auth') {
    if (ws.user) return send(ws, { type: 'auth_ok', profile: ws.user, onlineCount: onlineCount() });
    try {
      const { authUser, profile } = await verifyToken(String(msg.token || ''));
      ws.user = { id: authUser.id, email: authUser.email, username: profile.username, nickname: profile.nickname || profile.username };
      addOnline(authUser.id, ws);
      send(ws, { type: 'auth_ok', profile: ws.user, onlineCount: onlineCount() });
      for (const otherSockets of online.values()) for (const other of otherSockets) send(other, { type: 'online_count', count: onlineCount() });
    } catch (error) { send(ws, { type: 'auth_error', message: error.message || 'Could not authenticate session.' }); }
    return;
  }
  if (!ws.user) return sendError(ws, 'Authenticate first.');
  const now = Date.now();
  if (msg.type === 'input') {
    if (now - (ws.lastInputPacketAt || 0) < 25) return;
    ws.lastInputPacketAt = now;
    const room = getRoomFromSocket(ws), player = playerFrom(ws);
    if (!room || room.phase !== 'playing' || !player) return;
    let x = Math.max(-1, Math.min(1, Number(msg.x) || 0));
    let y = Math.max(-1, Math.min(1, Number(msg.y) || 0));
    const mag = Math.hypot(x,y); if (mag > 1) { x /= mag; y /= mag; }
    player.input = { x, y }; player.lastInputAt = now; return;
  }
  try {
    switch (msg.type) {
      case 'create_room': {
        if (findRoomByPlayer(ws.user.id)) throw new Error('You are already in a room. Leave it first.');
        const room = createRoom(ws.user, msg.mode, msg.map);
        ws.roomCode = room.code; room.players.get(ws.user.id).socket = ws;
        broadcastRoom(room); break;
      }
      case 'join_room': {
        if (findRoomByPlayer(ws.user.id)) throw new Error('You are already in a room. Leave that room first.');
        const code = String(msg.code || '').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);
        const room = rooms.get(code);
        if (!room) throw new Error('Room not found. Ask the host for a new code or invitation.');
        if (room.phase !== 'lobby') throw new Error('Mission already started; this room is not accepting new players.');
        if (room.players.size >= 6) throw new Error('Room is full (6/6 pilots).');
        room.players.set(ws.user.id, playerObject(ws.user));
        room.players.get(ws.user.id).socket = ws;
        ws.roomCode = code; broadcastRoom(room);
        sendEvent(room, `${ws.user.nickname} joined the room.`); break;
      }
      case 'leave_room': leaveRoom(ws); break;
      case 'set_ready': {
        const room = getRoomFromSocket(ws), p = playerFrom(ws);
        if (!room || !p || room.phase !== 'lobby') throw new Error('Ready can only be changed in lobby.');
        p.ready = room.hostId === p.id ? true : Boolean(msg.ready); broadcastRoom(room); break;
      }
      case 'set_settings': {
        const room = getRoomFromSocket(ws);
        if (!room || room.phase !== 'lobby') throw new Error('Mission settings can only change in lobby.');
        if (room.hostId !== ws.user.id) throw new Error('Only the host can choose mode and map.');
        if (!MODES.has(msg.mode) || !MAPS.has(msg.map)) throw new Error('Unknown mode or map.');
        room.mode = msg.mode; room.map = msg.map; broadcastRoom(room); break;
      }
      case 'start_match': {
        const room = getRoomFromSocket(ws);
        if (!room) throw new Error('Create or join a room first.');
        if (room.hostId !== ws.user.id) throw new Error('Only the host can start the mission.');
        beginMatch(room); break;
      }
      case 'action': {
        const room = getRoomFromSocket(ws), p = playerFrom(ws);
        if (!room || !p) throw new Error('You are not in a room.');
        doAction(room, p); broadcastRoom(room); break;
      }
      case 'invite_friend': {
        if (now - (ws.lastInviteAt || 0) < 2500) throw new Error('Wait a moment before sending another invitation.');
        ws.lastInviteAt = now;
        const room = getRoomFromSocket(ws);
        if (!room || room.phase !== 'lobby') throw new Error('You can only invite friends while in the lobby.');
        if (room.players.size >= 6) throw new Error('Room is full.');
        const targetId = String(msg.targetId || '');
        if (!/^[0-9a-f-]{36}$/i.test(targetId) || targetId === ws.user.id) throw new Error('Invalid friend selection.');
        if (room.players.has(targetId)) throw new Error('That friend is already in the room.');
        if (!(await isFriend(ws.user.id, targetId))) throw new Error('Only accepted friends can be invited.');
        await createNotification({ recipientId: targetId, actorId: ws.user.id, type: 'room_invite', payload: { roomCode: room.code, mode: room.mode, map: room.map } });
        sendToUser(targetId, { type: 'room_invite_notice', fromUsername: ws.user.username, fromNickname: ws.user.nickname, roomCode: room.code });
        send(ws, { type: 'invite_sent', targetId }); break;
      }
      case 'ping': send(ws, { type: 'pong', at: Date.now() }); break;
      default: sendError(ws, `Unsupported action: ${msg.type}`); break;
    }
  } catch (error) { sendError(ws, error?.message || 'Unexpected room error.'); }
}

httpServer.on('upgrade', (request, socket, head) => {
  const pathname = new URL(request.url, `http://${request.headers.host || 'localhost'}`).pathname;
  if (pathname !== '/multiplayer') { socket.destroy(); return; }
  wss.handleUpgrade(request, socket, head, (ws) => wss.emit('connection', ws, request));
});

wss.on('connection', (ws) => {
  ws.user = null; ws.roomCode = null; ws.lastInputPacketAt = 0;
  const authTimeout = setTimeout(() => { if (!ws.user) { send(ws, { type: 'auth_error', message: 'Authentication timeout. Sign in again.' }); ws.close(4001, 'auth timeout'); } }, 10000);
  ws.on('message', (raw) => { handleMessage(ws, raw).catch((error) => sendError(ws, error.message || 'Unexpected server error.')); });
  ws.on('close', () => {
    clearTimeout(authTimeout);
    if (ws.user) {
      const userId = ws.user.id;
      leaveRoom(ws, false);
      removeOnline(userId, ws);
      for (const sockets of online.values()) for (const other of sockets) send(other, { type: 'online_count', count: onlineCount() });
    }
  });
  ws.on('error', (error) => console.warn('[ws]', error.message));
});

setInterval(() => {
  const dt = 0.05;
  for (const room of rooms.values()) tickRoom(room, dt);
  // Clean up abandoned empty rooms defensively; regular leave/disconnect already removes them.
  const cutoff = Date.now() - 30 * 60 * 1000;
  for (const [code, room] of rooms) if (!room.players.size || room.createdAt < cutoff) rooms.delete(code);
}, 50).unref();

httpServer.listen(PORT, () => {
  console.log(`\n[NOVAEON Online] Local URL: http://localhost:${PORT}`);
  console.log(`[NOVAEON Online] Health:   http://localhost:${PORT}/api/health`);
  console.log(`[NOVAEON Online] Supabase: ${supabaseConfigured ? 'configured' : 'NOT configured — edit .env'}`);
  console.log('[NOVAEON Online] Room capacity: 6 pilots. Keep service-role keys server-side.\n');
});
