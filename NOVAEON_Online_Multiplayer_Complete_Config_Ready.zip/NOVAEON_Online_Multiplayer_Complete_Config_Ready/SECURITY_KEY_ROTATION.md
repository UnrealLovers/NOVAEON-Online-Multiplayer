# Tindakan keamanan Supabase — baca sebelum menjalankan

Secret key yang diberikan sebelumnya sudah dibagikan dalam chat. Perlakukan sebagai terekspos dan jangan gunakan ulang.

## Rotasi secret key
1. Masuk ke Supabase Dashboard dan pilih project NOVAEON.
2. Buka Settings -> API Keys.
3. Buat secret key baru (`sb_secret_...`). Jangan buat publishable key baru untuk langkah ini kecuali memang diperlukan.
4. Buka file `.env` lokal di folder yang sama dengan `package.json`.
5. Tempelkan key BARU setelah `SUPABASE_SERVICE_ROLE_KEY=` dan simpan.
6. Restart Node.js (`Ctrl+C`, lalu `npm start`).
7. Periksa `/api/health`, lalu uji sign-in, pencarian teman, dan room.
8. Setelah yakin semua layanan memakai key baru, hapus/revoke key lama dari Dashboard.

Jangan kirim secret key lewat chat, jangan masukkan ke HTML/JavaScript browser, dan jangan commit `.env` ke GitHub. File `.env` harus tetap di-ignore Git (aturan sudah ada di `.gitignore`).

Dokumentasi resmi Supabase:
https://supabase.com/docs/guides/getting-started/api-keys#rotate-a-leaked-or-compromised-key
