# NOVAEON Online Multiplayer Alpha — QA checklist

## Automated/static checks performed for this package
- `node --check server/index.js`
- `node --check public/js/multiplayer.js`
- Verify HTML integration anchors: `btn-multiplayer`, `mp-root`, runtime-config route script, client script.
- Verify room server constants: max 6 enforced on join; host-only mode/map changes and start; authenticated message gate; server-authoritative movement, pickup/action, mode timer.
- Verify `.env` is ignored and only `.env.example` is packaged.

## Must test with a configured Supabase project
- New registration creates one profile through the auth.users trigger.
- Duplicate/case-variant username is rejected by unique index.
- Profile username cannot be changed; nickname can be changed by owner.
- Friend request appears for recipient, remains pending until accepted/declined, only accepted request inserts friendship.
- Non-friends cannot receive a room invite through the WebSocket command.
- Room with 6 clients rejects client 7; only host can set mode/map/start.
- Disconnect, room host handover, timer expiry, win/loss paths, and duplicate action spam.
- Browser mobile pointer controls and WSS deployment.

No Supabase project credentials were provided, so live Auth, database policy execution, and multi-device WebSocket tests have not been run in this environment.
