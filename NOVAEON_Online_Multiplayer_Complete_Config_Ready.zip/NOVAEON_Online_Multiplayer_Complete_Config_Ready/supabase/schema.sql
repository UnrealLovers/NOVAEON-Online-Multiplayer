-- NOVAEON Online Multiplayer Alpha
-- Run once in Supabase Dashboard -> SQL Editor.
-- Account identity is backed by Supabase Auth. Never expose the service-role key to the browser.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  nickname text not null default 'Pilot',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint profiles_username_shape check (username ~ '^[a-z0-9_]{3,20}$'),
  constraint profiles_nickname_length check (char_length(nickname) between 1 and 24)
);
create unique index if not exists profiles_username_ci on public.profiles (lower(username));
create index if not exists profiles_username_prefix on public.profiles (username text_pattern_ops);

create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint friend_requests_not_self check (sender_id <> receiver_id)
);
create unique index if not exists friend_requests_pending_unique
  on public.friend_requests(sender_id, receiver_id) where status = 'pending';
create unique index if not exists friend_requests_pending_pair_unique
  on public.friend_requests(least(sender_id, receiver_id), greatest(sender_id, receiver_id)) where status = 'pending';
create index if not exists friend_requests_receiver_pending
  on public.friend_requests(receiver_id, created_at desc) where status = 'pending';

create table if not exists public.friendships (
  user_low uuid not null references public.profiles(id) on delete cascade,
  user_high uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_low, user_high),
  constraint friendships_ordered check (user_low < user_high)
);
create index if not exists friendships_user_high on public.friendships(user_high);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  type text not null check (type in ('friend_request','friend_request_accepted','friend_request_declined','room_invite','system')),
  payload jsonb not null default '{}'::jsonb,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists notifications_recipient_created
  on public.notifications(recipient_id, created_at desc);

create or replace function public.novaeon_touch_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at before update on public.profiles
for each row execute function public.novaeon_touch_updated_at();

drop trigger if exists friend_requests_touch_updated_at on public.friend_requests;
create trigger friend_requests_touch_updated_at before update on public.friend_requests
for each row execute function public.novaeon_touch_updated_at();

create or replace function public.novaeon_protect_profile_identity()
returns trigger language plpgsql set search_path = public as $$
begin
  if new.username <> old.username then
    raise exception 'USERNAME_IMMUTABLE';
  end if;
  return new;
end;
$$;
drop trigger if exists profiles_protect_username on public.profiles;
create trigger profiles_protect_username before update on public.profiles
for each row execute function public.novaeon_protect_profile_identity();

create or replace function public.novaeon_create_profile()
returns trigger language plpgsql security definer set search_path = public, auth as $$
declare
  v_username text;
  v_nickname text;
begin
  v_username := lower(trim(coalesce(new.raw_user_meta_data ->> 'username', '')));
  v_nickname := left(trim(coalesce(new.raw_user_meta_data ->> 'nickname', '')), 24);
  if v_username !~ '^[a-z0-9_]{3,20}$' then
    raise exception 'INVALID_USERNAME: use 3-20 lowercase letters, numbers, or underscores';
  end if;
  if v_nickname = '' then v_nickname := v_username; end if;
  insert into public.profiles(id, username, nickname) values (new.id, v_username, v_nickname);
  return new;
end;
$$;
drop trigger if exists nova_users_create_profile on auth.users;
create trigger nova_users_create_profile after insert on auth.users
for each row execute function public.novaeon_create_profile();

create or replace function public.search_profiles(p_query text)
returns table(id uuid, username text, nickname text)
language plpgsql stable security definer set search_path = public, auth as $$
declare
  v_query text := lower(trim(coalesce(p_query, '')));
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  if char_length(v_query) < 2 or char_length(v_query) > 20 or v_query !~ '^[a-z0-9_]+$' then
    raise exception 'INVALID_SEARCH';
  end if;
  return query
    select p.id, p.username, p.nickname
    from public.profiles p
    where p.id <> auth.uid() and left(lower(p.username), char_length(v_query)) = v_query
    order by p.username limit 10;
end;
$$;

create or replace function public.request_friend(p_username text)
returns uuid language plpgsql security definer set search_path = public, auth as $$
declare
  v_me uuid := auth.uid();
  v_target uuid;
  v_request uuid;
  v_low uuid;
  v_high uuid;
begin
  if v_me is null then raise exception 'AUTH_REQUIRED'; end if;
  select id into v_target from public.profiles where lower(username) = lower(trim(coalesce(p_username, '')));
  if v_target is null then raise exception 'USER_NOT_FOUND'; end if;
  if v_target = v_me then raise exception 'CANNOT_ADD_SELF'; end if;
  v_low := least(v_me, v_target); v_high := greatest(v_me, v_target);
  if exists(select 1 from public.friendships f where f.user_low = v_low and f.user_high = v_high) then
    raise exception 'ALREADY_FRIENDS';
  end if;
  if exists(select 1 from public.friend_requests r where r.status = 'pending' and ((r.sender_id = v_me and r.receiver_id = v_target) or (r.sender_id = v_target and r.receiver_id = v_me))) then
    raise exception 'REQUEST_PENDING';
  end if;
  insert into public.friend_requests(sender_id, receiver_id) values (v_me, v_target) returning id into v_request;
  insert into public.notifications(recipient_id, actor_id, type, payload)
    values (v_target, v_me, 'friend_request', jsonb_build_object('request_id', v_request));
  return v_request;
end;
$$;

create or replace function public.respond_friend_request(p_request_id uuid, p_accept boolean)
returns text language plpgsql security definer set search_path = public, auth as $$
declare
  v_me uuid := auth.uid();
  v_req public.friend_requests%rowtype;
  v_low uuid;
  v_high uuid;
begin
  if v_me is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_req from public.friend_requests
    where id = p_request_id and receiver_id = v_me and status = 'pending' for update;
  if not found then raise exception 'REQUEST_NOT_FOUND_OR_ALREADY_HANDLED'; end if;
  if p_accept then
    update public.friend_requests set status = 'accepted' where id = v_req.id;
    v_low := least(v_req.sender_id, v_req.receiver_id); v_high := greatest(v_req.sender_id, v_req.receiver_id);
    insert into public.friendships(user_low, user_high) values (v_low, v_high) on conflict do nothing;
    insert into public.notifications(recipient_id, actor_id, type, payload)
      values (v_req.sender_id, v_me, 'friend_request_accepted', jsonb_build_object('request_id', v_req.id));
    return 'accepted';
  else
    update public.friend_requests set status = 'declined' where id = v_req.id;
    insert into public.notifications(recipient_id, actor_id, type, payload)
      values (v_req.sender_id, v_me, 'friend_request_declined', jsonb_build_object('request_id', v_req.id));
    return 'declined';
  end if;
end;
$$;

-- Tight table access. All friend-request writes must go through the RPCs above.
alter table public.profiles enable row level security;
alter table public.friend_requests enable row level security;
alter table public.friendships enable row level security;
alter table public.notifications enable row level security;

revoke all on table public.profiles from anon, authenticated;
grant select on table public.profiles to authenticated;
grant update(nickname) on table public.profiles to authenticated;
drop policy if exists profiles_authenticated_read on public.profiles;
create policy profiles_authenticated_read on public.profiles for select to authenticated using (
  id = auth.uid()
  or exists (select 1 from public.friendships f where (f.user_low = auth.uid() and f.user_high = profiles.id) or (f.user_high = auth.uid() and f.user_low = profiles.id))
  or exists (select 1 from public.friend_requests r where r.status = 'pending' and ((r.sender_id = auth.uid() and r.receiver_id = profiles.id) or (r.receiver_id = auth.uid() and r.sender_id = profiles.id)))
  or exists (select 1 from public.notifications n where n.recipient_id = auth.uid() and n.actor_id = profiles.id)
);
drop policy if exists profiles_update_own_nickname on public.profiles;
create policy profiles_update_own_nickname on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

revoke all on table public.friend_requests from anon, authenticated;
grant select on table public.friend_requests to authenticated;
drop policy if exists friend_requests_read_participants on public.friend_requests;
create policy friend_requests_read_participants on public.friend_requests for select to authenticated
  using (sender_id = auth.uid() or receiver_id = auth.uid());

revoke all on table public.friendships from anon, authenticated;
grant select on table public.friendships to authenticated;
drop policy if exists friendships_read_participants on public.friendships;
create policy friendships_read_participants on public.friendships for select to authenticated
  using (user_low = auth.uid() or user_high = auth.uid());

revoke all on table public.notifications from anon, authenticated;
grant select on table public.notifications to authenticated;
grant update(is_read) on table public.notifications to authenticated;
drop policy if exists notifications_read_recipient on public.notifications;
create policy notifications_read_recipient on public.notifications for select to authenticated using (recipient_id = auth.uid());
drop policy if exists notifications_update_recipient on public.notifications;
create policy notifications_update_recipient on public.notifications for update to authenticated using (recipient_id = auth.uid()) with check (recipient_id = auth.uid());

revoke execute on function public.search_profiles(text) from public, anon;
revoke execute on function public.request_friend(text) from public, anon;
revoke execute on function public.respond_friend_request(uuid, boolean) from public, anon;
grant execute on function public.search_profiles(text) to authenticated;
grant execute on function public.request_friend(text) to authenticated;
grant execute on function public.respond_friend_request(uuid, boolean) to authenticated;

-- Note: online status and active rooms are ephemeral in the Node.js WebSocket server.
-- Room state is intentionally not written to account progress in this alpha.
